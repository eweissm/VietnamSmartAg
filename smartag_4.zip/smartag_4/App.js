import React, { useState } from 'react';
import {
  FlatList,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Constants from 'expo-constants';
import AssetExample from './components/Logo';
import { Card } from 'react-native-paper';

const DATA = [
  {
    id: '1',
    title: 'Sensor Selection ',
    state: 2,
  },
  {
    id: '5',
    title: 'Data Input',
    state: 3,
  },
  {
    id: '2',
    title: 'Field Info',
    state: 4,
  },
  {
    id: '4',
    title: "Your Field's Health",
    state: 5,
  },
  {
    id: '6',
    title: 'Watering Schedule',
    state: 6,
  },
];

const Item = ({ item, onPress, backgroundColor, textColor }) => (
  <TouchableOpacity onPress={onPress} style={[styles.item, backgroundColor]}>
    <Text style={styles.title}>{item.title}</Text>
  </TouchableOpacity>
);

const DATASensors = [
  {
    id: 'SoilMoisture',
    title: 'SoilMoisture',
    choosen: false,
  },
  {
    id: 'CWSI',
    title: 'CWSI',
    choosen: false,
  },
  {
    id: 'Weather Data',
    title: 'Weather Data',
    choosen: false,
  },
  {
    id: 'Taste Test',
    title: 'Taste Test',
    choosen: false,
  },
];

const ItemSensor = ({ itemSensor, onPress, backgroundColorSensor, textColorSensor }) => (
  <TouchableOpacity
    onPress={onPress}
    style={[styles.itemSensor, backgroundColorSensor]}>
    <Text style={styles.title}>{itemSensor.title}</Text>
  </TouchableOpacity>
);

const App = () => {
  const [state, setState] = useState(0);
  const titleButton = () => setState(1);
  const returnButton = () => setState(0);

  const [selectedId, setSelectedId] = useState(null);

  const renderItem = ({ item }) => {
    const backgroundColor = item.id === selectedId ? '#76D7C4' : 'green';
    const color = item.id === selectedId ? 'white' : 'black';

    return (
      <Item
        item={item}
        onPress={() => setState(item.state)}
        backgroundColor={{ backgroundColor }}
        textColor={{ color }}
      />
    );
  };

  const [selectedSensorId, setSelectedSensorId] = useState(null);

    const renderSensorItem = ({ item }) => {
    const backgroundColor = item.choosen ? '#76D7C4' : 'white';
    const color = item.choosen ? 'white' : 'black';

    return (
      <Item
        item={item}
        onPress={() => this.item.choosen = true}
        backgroundColor={{ backgroundColor }}
        textColor={{ color }}
      />
    );
  };

  if (state == 0) {
    //home page
    return (
      <View style={styles.container1}>
        <AssetExample />
        <TouchableOpacity style={styles.button} onPress={titleButton}>
          <Text style={styles.buttonStyle}>Get Started</Text>
        </TouchableOpacity>
      </View>
    );
  } else if (state == 1) {
    //category selection
    return (
      <View style={styles.categoryButtons}>
        <Text style={styles.SelectionScreenText}>Select a category</Text>
        <FlatList data={DATA} renderItem={renderItem} />
      </View>
    );
  } else if (state == 2) {
    //sensor selection
    return (
      <View style={styles.categoryButtons}>
        <Text style={styles.title}>sensor selection (wip) </Text>
        <FlatList data={DATASensors} renderItem={renderSensorItem} />
        <TouchableOpacity
          style={styles.returnStyle}
          onPress={() => setState(0)}>
          <Text style={styles.buttonStyle}>Home Screen</Text>
        </TouchableOpacity>
      </View>
    );
  } else if (state == 3) {
    //data input
    return (
      <View style={styles.container3}>
        <Text style={styles.title}>data input (wip) </Text>

        <TouchableOpacity
          style={styles.returnStyle}
          onPress={() => setState(0)}>
          <Text style={styles.buttonStyle}>Home Screen</Text>
        </TouchableOpacity>
      </View>
    );
  } else if (state == 4) {
    // field info
    return (
      <View style={styles.container3}>
        <Text style={styles.title}>field info (wip)</Text>

        <TouchableOpacity
          style={styles.returnStyle}
          onPress={() => setState(0)}>
          <Text style={styles.buttonStyle}>Home Screen</Text>
        </TouchableOpacity>
      </View>
    );
  } else if (state == 5) {
    // fields health
    return (
      <View style={styles.container3}>
        <Text style={styles.title}> fields health (wip)</Text>

        <TouchableOpacity
          style={styles.returnStyle}
          onPress={() => setState(0)}>
          <Text style={styles.buttonStyle}>Home Screen</Text>
        </TouchableOpacity>
      </View>
    );
  } else if (state == 6) {
    // water schedule
    return (
      <View style={styles.container3}>
        <Text style={styles.title}>water schedule (wip)</Text>

        <TouchableOpacity
          style={styles.returnStyle}
          onPress={() => setState(0)}>
          <Text style={styles.buttonStyle}>Home Screen</Text>
        </TouchableOpacity>
      </View>
    );
  }
};
const styles = StyleSheet.create({
  container1: {
    flex: 1,
    justifyContent: 'Center',
    alignItems: 'center',
    paddingTop: 10,
    backgroundColor: '#b5d0d9',
    padding: 8,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#8fe388',
    padding: 10,
  },
  buttonStyle: {
    alignItems: 'center',
    padding: 10,
    fontSize: 20,
    color: '#943126',
  },
  returnStyle: {
    alignItems: 'center',
    backgroundColor: '#8fe388',
    position: 'absolute',
    bottom: 20,
    left: 20,
  },
  categoryButtons: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#138D75',
    //marginTop: StatusBar.currentHeight || 0,

    paddingTop: 100,
  },
  item: {
    marginVertical: 10, //space between buttons
    padding: 10, //box around text
    alignItems: 'center',
    justifyContent: 'Center',
  },
  itemSensor: {
    marginVertical: 10, //space between buttons
    padding: 10, //box around text
    alignItems: 'center',
    justifyContent: 'Center',
  },
  title: {
    fontSize: 20,
    justifyContent: 'Center',
  },
  container3: {
    flex: 1,
    justifyContent: 'Center',
    alignItems: 'center',
    paddingTop: 10,
    backgroundColor: '#F3E5AB',
    padding: 8,
  },
  SelectionScreenText: {
    justifyContent: 'Center',
    fontSize: 20,
    color: '#FDFEFE',
  },
});

export default App;
